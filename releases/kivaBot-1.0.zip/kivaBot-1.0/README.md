# KivaBot
KivaBot is tool for the MMORPG Freewar which allows the automatic collection of ressources.

The available documentation can be found in [our wiki](https://github.com/ZabuzaW/KivaBot/wiki).
